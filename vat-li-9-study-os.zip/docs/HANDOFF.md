# Bàn giao kỹ thuật — Học mọi thứ · v10.0

Tài liệu này là “bộ nhớ” của dự án: đọc hết là có thể sửa, mở rộng và kiểm thử mà không cần hỏi lại.
Cập nhật lần cuối: **2026-10-21** · phiên bản **10.0.0** · build **976.330 B**.

---

## 1. Triết lý

1. **Một tệp, chạy được ngay.** `index.html` chứa toàn bộ CSS/JS/dữ liệu. Không API AI, không CDN bắt buộc,
   không đăng nhập. Mở bằng trình duyệt là dùng; copy sang máy khác vẫn chạy.
2. **Không có “trang trí rỗng”.** Mỗi khối trên giao diện phải gắn với dữ liệu thật của người học.
3. **Dữ liệu thuộc về người học.** Lưu trong `localStorage` + IndexedDB, xuất được ra `.json`, in được ra giấy.
4. **Tiếng Việt trong giao diện, tiếng Anh trong mã.** Tên biến/hàm tiếng Anh, chữ hiển thị tiếng Việt có dấu.

---

## 2. Kiến trúc build

```
src/base.html          khung HTML gốc (title, meta, header/footer, các vùng chứa)
src/*.js               mô-đun, ghép theo thứ tự cố định trong src/build.py
src/app.css            toàn bộ CSS (176 KB, gồm 13 theme)
        │
        ▼  python3 src/build.py
index.html             bản chạy duy nhất
```

`src/build.py` đọc `src/base.html`, chèn 5 khối `<script>` theo thứ tự:

| Khối | Nội dung |
|---|---|
| 1 | `data` — lộ trình 52 ca sinh từ `base.html` + `papers.js` |
| 2 | `qa` — `qa.js` + `content2/3/4.js` (hỏi đáp, trắc nghiệm, bài đọc) |
| 3 | `store` + `app` + `tools` + `engine` — lõi ứng dụng, router, tìm kiếm |
| 4 | `solver`, `teacher`, `board`, `sim`, `school`, `seed_more`, `study`, **`sched`**, `music`, `pomo`, `settings`, `lab` |

> **Thứ tự có ý nghĩa:** `study.js` gọi `schTodaySummary()` nếu tồn tại (kiểm tra `typeof`), nên `sched` đứng sau.
> `settings.js` cần đứng trước `lab.js`. Đổi thứ tự phải chạy lại `tools/check.js` và bộ QA.

Lệnh:
```bash
python3 src/build.py                 # mặc định: src/base.html → index.html
python3 src/build.py --base X --out Y
node tools/check.js                  # 5 khối script + CSS + dấu hiệu nhận diện
```

---

## 3. Bản đồ route

| Route | Hàm | Ghi chú |
|---|---|---|
| `#/` | `renderHome` | hero, dải Học hôm nay, `.hero-sign` |
| `#/day/:id` | `renderDay` | một ngày trong lộ trình |
| `#/lesson/:d/:i` | `renderLesson` | bài đọc, ghi chú, Feynman, đọc thành tiếng |
| `#/library`, `#/notes` | `renderLibrary`, `renderNotes` | thư viện, ghi chú |
| `#/papers`, `#/exam`, `#/review`, `#/solve/:i` | | đề, phòng thi, chữa đề, máy giải |
| `#/qa`, `#/flash`, `#/stats`, `#/calc` | | hỏi đáp, thẻ cũ, thống kê, máy tính |
| `#/build`, `#/sim`, `#/lab` | `renderBoard`, `renderSim`, `renderLab` | bảng vẽ, mô phỏng, 4 bàn thí nghiệm |
| `#/subjects`, `#/subject/:lop/:mon` | | trường học lớp 1–12 |
| `#/read/:id`, `#/studio`, `#/mine`, `#/files` | | đọc bài, tự soạn, bài của tôi, tệp |
| **`#/study`** | `renderStudy` | Study OS + khối `sy-today` |
| **`#/cards`** | `renderCards` | thẻ 7 hộp |
| **`#/practice`** | `renderPractice` | luyện đề tự tạo |
| **`#/plan`** | `renderPlan` | kế hoạch tới ngày thi |
| **`#/focus`** | `renderFocus` | đồng hồ tập trung |
| **`#/progress`** | `renderProgress` | tiến độ tổng |
| **`#/timetable`** | `renderTimetable` | v10 |
| **`#/calendar`** | `renderCalendar` | v10 |
| **`#/about`** | `renderAbout` | v10 — chủ sở hữu, GitHub |
| `#/settings` | `renderSettings` | theme, màu nhấn, cỡ chữ, nhạc |

Router nằm cuối `src/app.js` — một chuỗi `if (p[0]===…) return render…()`, mặc định `renderHome()`.

---

## 4. Lược đồ dữ liệu

### `localStorage['vnl9.v2']` — trạng thái chính
```js
{
  done: [],            // id câu đã làm đúng
  watched: [],         // video đã xem
  ans: {},             // đáp án theo câu
  mine: [],            // bài tự soạn
  note: {},            // ghi chú theo bài
  runs: [],            // lịch sử luyện đề
  days: {},            // 'YYYY-MM-DD' → số hoạt động (heatmap, chuỗi)
  calc: {}, book: {}, sheet: {},
  music: {…}, pomo: {…},
  goal: { min: 60, cards: 20 },
  study: { cards: [], plan: {…}, log: [], … },   // Study OS (v9)
  sched: {…}                                     // v10 — xem dưới
}
```
`localStorage['vnl9.prefs']` giữ `theme`, `accent`, `size`, `music`, `sound`.
`vnl9.b1` / `vnl9.b2` là bản sao luân phiên; ghi lỗi thì còn bản kia.

### `state.sched` (v10)
```js
{
  tables: [{
    id: 'tkb1', name: 'Thời khoá biểu chính khoá',
    days: 6, morning: 5, afternoon: 3,
    cells: { 'd-k-i': { s: 'Vật lí', t: 'Tiết 1', r: 'Cô Hoa', c: 'brick' } }
  }],
  activeId: 'tkb1',
  events: [{
    id, date: '2026-11-14', time: '19:00', title, color, kind: 'study|exam|deadline|other',
    note, done: false, src: 'tt'    // src = sinh từ thời khoá biểu
  }],
  calView: 'month' | 'week',
  cursor: '2026-11-14'
}
```

### API nội bộ quan trọng
| Hàm | Việc |
|---|---|
| `schedState()` | lấy/khởi tạo `state.sched` |
| `schedTable()` | bảng đang mở |
| `renderTimetable()` / `renderCalendar()` | vẽ trang |
| `schAutoFill(T)` → `schApplyAuto(T, list)` | overlay nhập môn → rải đều + tô màu |
| `schPushWeek(T)` | đổ một tuần TKB thành việc trong lịch, chống trùng `ngày+giờ+tên+src` |
| `schICS()` | tải `.ics` (RFC 5545) |
| `schTodaySummary()` | `{ today[], next, days }` — dùng cho dashboard |
| `schColor(id)` | trả `{ bg, fg, dot }` theo 12 màu bảng |
| `calAdd(o)` / `calEditor(ev, iso)` | thêm việc / hộp thoại sửa việc |
| `SCH_ISO(date)` / `SCH_VN(iso)` | chuyển ngày ISO ↔ `dd/mm/yyyy` |
| `uiPrompt(title, def, onOk, opt)` | hộp nhập nội trang (thay `prompt()`) |
| `uiCardForm()` | form thẻ nhanh |

---

## 5. Giao diện

- Token: `--paper` (nền trang), `--card`, `--ink` (chữ chính), `--ink2` (chữ phụ), `--accent`, `--line`.
  Không hard-code màu; luôn dùng biến để theme đổi được.
- 13 theme khai báo trong `src/settings.js` → sinh `html[data-theme=…]` trong `app.css`.
  Theme tối (`midnight`, `graphite`, `pixelnight`) có khối override riêng — **thêm theme tối mới phải bổ sung vào đó**
  nếu muốn rail lộ trình và bảng thí nghiệm đọc được.
- Thành phần dùng lại: `.wrap.wide`, `.page-head`, `.kicker`, `.btn` / `.btn.ghost` / `.btn.sm`,
  `.sy-box` + `.sy-box-h/f`, `.cal-*` (lịch), `.tt-*` (thời khoá biểu), `.ab-*` (about), `.overlay` + `.ov-panel` (hộp thoại).
- In ấn: `@media print` ẩn chrome; `.tt-brand` in dòng `@nggkhaiz · github.com/Ngg.Khaiz`.
- Nơi đặt tag chủ sở hữu: hero (`.hero-sign`), topbar (`.tb-owner`), footer (`.foot-own`), `#/about`, `<title>`,
  `<meta name="description">`, bản in, `document.title` từng trang có tiền tố thương hiệu.

---

## 6. Quy tắc viết mã (rút ra từ lỗi thật)

1. **Không dùng `prompt()`, `confirm()`, `alert()`.** Chạy trong iframe/preview sẽ bị chặn và treo QA.
   Dùng `uiPrompt`, `uiCardForm`, hoặc `.overlay` tự dựng.
2. **Không đặt biến cục bộ trùng tên helper toàn cục** (`esc`, `$`, `$$`, `toast`, `save`, `state`).
   Đã từng gây `TypeError` khi mở hộp thoại lịch vì `const esc = e => …` che `esc()`.
3. **Không gọi mạng.** Preview của Workspace không có network: ảnh phải là SVG inline hoặc data URI.
   Video/âm thanh do người dùng tự dán link.
4. **Mọi thứ ghi vào `state` phải `save()` ngay** và phải chịu được tải lại trang (QA kiểm bằng `location.reload()`).
5. **Không gắn `document.onkeydown` trực tiếp.** Dùng hàm bind + hàm `*Cleanup()` gọi trong router,
   nếu không phím tắt sẽ rò sang trang khác.
6. **Dedupe khi sinh dữ liệu hàng loạt.** Khoá phải đủ đặc (`ngày + giờ + tên + nguồn`), nếu không bấm hai lần sẽ nhân đôi.
7. **Ô lịch tối thiểu 104px**, chấm màu thay vì nhồi chữ; chữ trong ô 10–11px.
8. **Trước khi kết luận “đã xong” phải mở trình duyệt thật**: render đúng chưa, có tràn ngang không, console có lỗi không.

---

## 7. Chạy bộ kiểm thử

QA chạy trong trình duyệt thật bằng [`playwright-cli`](https://github.com/microsoft/playwright), mỗi tệp là **một biểu thức JS**
trả về `{rounds, pass, total, errors}`.

```bash
python3 -m http.server 8124            # phục vụ thư mục repo
playwright-cli -s=qa open "http://localhost:8124/index.html" --browser=chromium
playwright-cli -s=qa resize 1500 1000
playwright-cli -s=qa eval "$(cat tools/qa/sched.js)"
```

| Tệp | Số bước | Nội dung |
|---|---|---|
| `sched.js` | 21 | lưới 48 ô, tạo bảng, tự xếp 47 tiết, sửa/xoá tiết, đổi số ngày, lịch 42 ô, thêm việc, màu theo loại, tick xong, xem tuần, chuyển tuần, 6 theme, about, tag topbar/footer, in ấn, `.ics`, đổ TKB → lịch, khối hôm nay, dọn dữ liệu, 0 lỗi |
| `study.js` | 21 | dashboard, thẻ, ôn, luyện đề, kế hoạch, đồng hồ, ghi chú, Feynman, TTS, heatmap, tiến độ, sao lưu, phím tắt |
| `school.js` | 26 | 12 lớp × môn, đọc bài, tạo bài, xuất/nhập |
| `board.js` | 17 | kéo–thả, nối dây, xoá, lưu |
| `sim.js` | 19 | mô phỏng quang – cơ – điện |
| `audit.js` | 30 route | tràn ngang, phần tử bị cắt, lỗi JS — chạy ở 1500×1000 và 390×844 |

**Mẹo:** mỗi tệp QA tự dọn dữ liệu nó tạo (`QA …`) và kết thúc bằng bước “không lỗi JS”.
Sau `location.reload()` phải tách lần `eval` — không dùng được trong cùng một lượt.

---

## 8. Bài học & bẫy đã gặp

| Triệu chứng | Nguyên nhân | Cách xử lý |
|---|---|---|
| Bấm ô lịch không mở hộp thoại, console `Cannot set properties of null` | `const esc` trong `calEditor` che `esc()` toàn cục | đổi tên thành `onEsc` |
| Chữ ở rail gần như mất trên nền tối | nền `--paper` sáng + chữ `--paper` | override `html[data-theme=…] .rs-main` |
| Đổ TKB vào lịch chỉ được 6 việc | chống trùng chỉ theo `ngày+tên` | thêm `giờ` vào khoá |
| Dán 5 môn thành 1 môn | chỉ tách dấu phẩy | tách `[,;\n\r]+` + `Set` |
| Onboarding che mất trang khi chụp QA | overlay “Lần đầu mừng” | bấm “Để sau” hoặc xoá `.overlay` trước khi chụp |
| `eval` sau `location.reload()` trả `null` | trang đang tải lại | tách thành 2 lần gọi, chờ 1–2 giây |
| Server dev chết giữa các phiên | tiến trình nền bị dọn | `curl` kiểm tra, nếu 000 thì `start_process` lại |

---

## 9. Định hướng

1. Xuất thời khoá biểu/lịch ra **ảnh PNG** (dùng `<canvas>` hoặc `foreignObject` → `toDataURL`, không thư viện).
2. **Sinh lịch ôn ngược**: từ ngày thi + danh sách chủ đề → chia mốc, đẩy vào `#/plan` và `#/calendar`.
3. Badge “N việc hôm nay” ở topbar, cập nhật khi thêm/xong việc.
4. Xuất/nhập **toàn bộ** `state.sched` để chuyển máy (hiện đã nằm trong sao lưu Study OS).
5. Đồng bộ Google Calendar hai chiều (một chiều đã có qua `.ics`) — cần OAuth, sẽ phá vỡ nguyên tắc “không máy chủ”;
   nếu làm, phải là tuỳ chọn và có cảnh báo.

---

## 10. Chuyển giao

```bash
git init
git add .
git commit -m "v10.0 — thời khoá biểu, kế hoạch, lịch, chữ ký tác giả"
git branch -M main
git remote add origin https://github.com/<tài-khoản>/vat-li-9-study-os.git
git push -u origin main
```

Sau khi push: **Settings → Pages → Source: GitHub Actions**. Workflow `pages.yml` sẽ deploy;
`check.yml` chặn merge nếu `index.html` không khớp bản dựng lại từ `src/` hoặc có lỗi cú pháp.

© 2026 **@nggkhaiz** — [github.com/Ngg.Khaiz](https://github.com/Ngg.Khaiz) · MIT
